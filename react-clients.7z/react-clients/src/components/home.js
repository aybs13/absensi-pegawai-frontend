import React from "react";
import { Container, Row, Col, Button } from "react-bootstrap";
import "./Home.css"; // Mengimpor file CSS terpisah dengan nama Home.css

const Home = ({ title }) => {
    return (
        <div className="background-container">
            <Container className="glass-container">
                <Row className="justify-content-center align-items-center" style={{ height: "100vh" }}>
                    <Col xs={10} md={6} lg={4}>
                        <h1 className="text-center">{title}</h1>
                        <p className="text-center">Welcome to Mini Absensi App</p>
                        <div className="text-center">
                            <Button variant="dark" href="/login">Login</Button>{' '}
                            <Button variant="outline-dark" href="/register">Register</Button>
                        </div>
                    </Col>
                </Row>
            </Container>
        </div>
    );
}

export default Home;