    import React, { useState, useEffect } from "react";
    import ReactTypingEffect from "react-typing-effect";
    import { Container, Form, Button } from "react-bootstrap";
    import axios from "axios";
    import { useNavigate } from "react-router-dom";

    function Login({ title, description }) {
    const [NIP, setNip] = useState("");
    const [password, setPassword] = useState("");
    const [error, setError] = useState("");

    const navigate = useNavigate();

    const handleNIP = (event) => {
        const inputNIP = event.target.value;
        setNip(inputNIP);
    };

    const handlePassword = (event) => {
        const inputPassword = event.target.value;
        setPassword(inputPassword);
    };

    const userLogin = () => {
        if (NIP.trim() === "" || password.trim() === "") {
        setError("NIP dan password harus diisi");
        return;
        }

        const requestingData = {
        nip: NIP,
        password: password,
        };

        axios
        .post("http://localhost:3200/users/login", requestingData)
        .then((result) => {
            localStorage.setItem("nip", result.data.users.nip);
            localStorage.setItem("nama", result.data.users.nama);
            navigate("/dashboard");
        })
        .catch((error) => {
            setError("Terjadi kesalahan saat login");
        });
    };

    useEffect(() => {
        const isLoggedIn = localStorage.getItem("nip");
        if (isLoggedIn) {
        navigate("/dashboard");
        }
    }, [navigate]);

    return (
        <Container>
        <div className="d-flex justify-content-center fw-bold h5 my-4">
            <ReactTypingEffect
            text={[title, description]}
            speed={100}
            eraseDelay={800}
            eraseSpeed={100}
            typingDelay={100}
            />
        </div>
        <div className="d-flex justify-content-center">
            <Form className="w-25">
            <Form.Group>
                <Form.Label className="fw-bold">NIP</Form.Label>
                <Form.Control
                type="number"
                placeholder="Masukkan NIP Anda"
                value={NIP}
                onChange={handleNIP}
                required
                />
            </Form.Group>
            <Form.Group>
                <Form.Label className="fw-bold">Password</Form.Label>
                <Form.Control
                type="password"
                placeholder="***"
                value={password}
                onChange={handlePassword}
                required
                />
            </Form.Group>
            {error && <p className="text-danger">{error}</p>}
            <Button className="mt-4 w-100 btn-dark" onClick={userLogin}>
                Login Sekarang
            </Button>
            </Form>
        </div>
        </Container>
    );
    }

    export default Login;
