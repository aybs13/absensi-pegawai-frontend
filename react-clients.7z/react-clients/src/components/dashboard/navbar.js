    import React from "react";

    const Navbar = () => {
    return (
        <nav className="navbar navbar-expand-md navbar-dark bg-dark">
        <div className="container-fluid">
            <a className="navbar-brand" href="#">
            {localStorage.getItem("nama")}
            </a>
            <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarNav"
            aria-controls="navbarNav"
            aria-expanded="false"
            aria-label="Toggle navigation"
            >
            <span className="navbar-toggler-icon"></span>
            </button>
            <div className="collapse navbar-collapse" id="navbarNav">
            <ul className="navbar-nav ms-auto">
                <li className="nav-item">
                <a className="nav-link" href="#">
                    Share
                </a>
                </li>
                <li className="nav-item">
                <a className="nav-link" href="#">
                    Export
                </a>
                </li>
                <li className="nav-item dropdown">
                <a
                    className="nav-link dropdown-toggle"
                    href="#"
                    id="navbarDropdown"
                    role="button"
                    data-bs-toggle="dropdown"
                    aria-expanded="false"
                >
                    <span className="align-text-bottom">This week</span>
                </a>
                <ul className="dropdown-menu" aria-labelledby="navbarDropdown">
                    <li>
                    <a className="dropdown-item" href="#">
                        Option 1
                    </a>
                    </li>
                    <li>
                    <a className="dropdown-item" href="#">
                        Option 2
                    </a>
                    </li>
                    <li>
                    <hr className="dropdown-divider" />
                    </li>
                    <li>
                    <a className="dropdown-item" href="#">
                        Other option
                    </a>
                    </li>
                </ul>
                </li>
            </ul>
            </div>
        </div>
        </nav>
    );
    };

    export default Navbar;
