    import { useEffect, useState } from "react";
    import { Container, Button, Badge } from "react-bootstrap";
    import axios from "axios";
    import Navbar from "./navbar";
    import Edit from "./edit";
    import { logout } from './logout';

    function Dashboard({ title }) {
    const [absensiList, setAbsensiList] = useState([]);
    const [absenNotif, setAbsenNotif] = useState(false);
    const [alreadyCheckIn, setAlreadyCheckIn] = useState(false);
    const [alreadyCheckOut, setAlreadyCheckOut] = useState(false);

    useEffect(() => {
        if (!localStorage.getItem("nama") && !localStorage.getItem("nip")) {
        console.log("user belum login");
        window.location.replace("/login");
        }

        axios({
        method: "GET",
        url: "http://localhost:3200/absensi"
        }).then((result) => {
        setAbsensiList(result.data.absensi);

        // Cek apakah pengguna sudah melakukan check-in atau check-out hari ini
        const today = new Date().toISOString().split("T")[0];
        const todayAbsensi = result.data.absensi.find(
            (absensi) => absensi.createdAt.split("T")[0] === today
        );

        if (todayAbsensi) {
            if (todayAbsensi.status === "checkin") {
            setAlreadyCheckIn(true);
            } else if (todayAbsensi.status === "checkout") {
            setAlreadyCheckOut(true);
            }
        } else {
            setAlreadyCheckIn(false);
            setAlreadyCheckOut(false);
        }
        });
    }, [absenNotif]);

    const absen = (params) => {
        // Cek apakah pengguna sudah melakukan check-in atau check-out hari ini
        if ((params === "checkin" && alreadyCheckIn) || (params === "checkout" && alreadyCheckOut)) {
        alert("Anda sudah melakukan absensi hari ini.");
        return;
        }

        const requestData = {
        nip: localStorage.getItem("nip")
        };

        axios({
        method: "POST",
        url: `http://localhost:3200/absensi/${params}`,
        data: { nip: localStorage.getItem("nip") }
        }).then(() => {
        setAbsenNotif(!absenNotif);
        });
    };

    return (
        <Container>
        <main className="col-md-12 ms-sm-auto col-lg-12 px-md-4">
            <Navbar />
            <h2>{title}</h2>
            <div>
            <p>Hello {localStorage.getItem("nama")}!</p>
            <p>nip {localStorage.getItem("nip")} </p>
            <Button onClick={() => logout()} className="mt-2" size="sm" variant="danger">
                Logout
            </Button>
            </div>
            <Edit title="Edit Profile" />
            <div className="table-responsive">
            <table className="table table-striped table-sm">
                <thead>
                <tr>
                    <th scope="col">no.</th>
                    <th scope="col">NIP</th>
                    <th scope="col">Status</th>
                    <th scope="col">Tanggal</th>
                </tr>
                </thead>
                <tbody>
                {absensiList.map((absensi, i) => {
                    const { users_nip, status, createdAt } = absensi;
                    return (
                    <tr key={i}>
                        <td>{i + 1}</td>
                        <td>{users_nip}</td>
                        <td>{status}</td>
                        <td>{new Date(createdAt).toLocaleString()}</td>
                    </tr>
                    );
                })}
                </tbody>
            </table>
            </div>
            <div className="d-flex  gap-2">
            <Badge pill bg="primary" style={{ cursor: "pointer" }} onClick={() => absen("checkin")} disabled={alreadyCheckIn}>
                Check-in
            </Badge>
            <Badge pill bg="danger" style={{ cursor: "pointer" }} onClick={() => absen("checkout")} disabled={alreadyCheckOut}>
                Check-out
            </Badge>
            </div>
        </main>
        </Container>
    );
    }

    export default Dashboard;
