    import { Form, Button } from "react-bootstrap"
    import { useState } from "react"
    import Axios from "axios"
    import { logout } from "./logout"

    const Edit = ({ title }) => {

    const [nama, setNama] = useState(localStorage.getItem("nama"))
    const [password, setPassword] = useState("")
    const [passwordBaru, setPasswordBaru] = useState("")

    const updateProfile = () => {
        const requestingData = {
        nip: localStorage.getItem("nip"),
        nama: nama,
        password: password,
        passwordBaru: passwordBaru,
        nama: nama
        }
        Axios({
        method: "PUT",
        url: "http://localhost:3200/users",
        data: requestingData
        }).then(() => {
            alert("anda akan keluar dari sistem, silahkan login kembali")
            logout()
        })
    }

    return (
        <div>
        <h1>{title}</h1>
        <Form>
            <Form.Group>
            <Form.Label>Nama</Form.Label>
            <Form.Control onChange={(event) => setNama(event.target.value)} defaultValue={ localStorage.getItem("nama") } />
            </Form.Group>
            <Form.Group>
            <Form.Label>Password Lama</Form.Label>
            <Form.Control onChange={(event) => setPassword(event.target.value)}/>
            </Form.Group>
            <Form.Group>
            <Form.Label>Password Baru</Form.Label>
            <Form.Control onChange={(event) => setPasswordBaru(event.target.value)}/>
            </Form.Group>
            <Form.Group>
            <Form.Text>Silahkan masukkan password lama anda. Anda diharuskan melakukan login ulang setelah mengupdate password.</Form.Text>
            </Form.Group>
            <Button onClick={() => updateProfile()}>Update Profile</Button>
        </Form>
        </div>
    )
    }

    export default Edit